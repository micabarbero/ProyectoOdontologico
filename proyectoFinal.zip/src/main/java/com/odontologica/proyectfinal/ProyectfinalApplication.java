package com.odontologica.proyectfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectfinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectfinalApplication.class, args);
	}

}
