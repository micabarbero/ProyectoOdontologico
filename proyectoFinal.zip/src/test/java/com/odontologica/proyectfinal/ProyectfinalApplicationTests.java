package com.odontologica.proyectfinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectfinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
